package com.androidatc.finalcourseproject

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Switch
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_preference.*

class PreferenceActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preference)

        val dS = findViewById<Switch>(R.id.darkToggle)

        dS?.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) prefLayout.setBackgroundColor(0xFF7C2626.toInt()) else prefLayout.setBackgroundColor(0xFF9E3131.toInt())
            if (isChecked) settingsText.setBackgroundColor(0xFF00786D.toInt()) else settingsText.setBackgroundColor(0xFF009A8B.toInt())
        }

        val tS = findViewById<Switch>(R.id.themeToggle)

        tS?.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) imageView.alpha = 1F else imageView.alpha = 0F
            if (isChecked) darkToggle.setBackgroundColor(0xFF9E3131.toInt()) else darkToggle.setBackgroundColor(0x009E3131.toInt())
            if (isChecked) themeToggle.setBackgroundColor(0xFF9E3131.toInt()) else themeToggle.setBackgroundColor(0x009E3131.toInt())
            if (isChecked) subText4.alpha = 1F else subText4.alpha = 0F
        }
    }
}