package com.androidatc.finalcourseproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        godsBtn.setOnClickListener{
            val intent = Intent(this, SecondActivity::class.java)

            startActivity(intent)
        }
        /*creaturesBtn.setOnClickListener{
            val intent = Intent(this, SecondActivity2::class.java)

            startActivity(intent)
        }*/
        settingsBtn.setOnClickListener{
            val intent = Intent(this, PreferenceActivity::class.java)

            startActivity(intent)
        }
        helpBtn.setOnClickListener{
            val intent = Intent(this, HelpActivity::class.java)

            startActivity(intent)
        }
    }
}