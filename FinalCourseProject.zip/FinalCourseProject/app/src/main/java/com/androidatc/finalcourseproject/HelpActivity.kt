package com.androidatc.finalcourseproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_help.*

class HelpActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help)

        appBtn.setOnClickListener{
            changingText.text = "This application functions as a catalogue for various mythological" +
                    " deities and creatures that are sorted according to their home mythology." +
                    " Any overlap (meaning creatures or deities that exist in multiple mythologies) will " +
                    "be listed in every mythology they are part of, but using the version that exists in " +
                    "that mythology."
        }

        deityBtn.setOnClickListener{
            changingText.text = "This button will lead you to a menu requesting you select a mythology. " +
                    "Upon selecting one, it will bring you to a catalogue of deities according to the " +
                    "mythology you selected."
        }

        creatureBtn.setOnClickListener{
            changingText.text = "This button will lead you to a menu requesting you select a mythology. " +
                    "Upon selecting one, it will bring you to a catalogue of creatures according to the " +
                    "mythology you selected. Whenever a creature exists in more than one mythology, the " +
                    "selected mythology will only address the version that exists in that mythology."
        }

        settingBtn.setOnClickListener{
            changingText.text = "The settings menu is where this will lead as you can probably guess. Although, " +
                    "in this case it works more like a preference menu rather than settings, allowing you to" +
                    " change the color theme of the application and toggle the mythology themed wallpapers." +
                    " The mythology wallpapers will be different according to the mythology selected."
        }

        catalogueBtn.setOnClickListener{
            changingText.text = "Just to be clear, this is info about how the different catalogues work. They " +
                    "are all sorted alphabetically and will give some detailed information, but if certain details" +
                    " won't make sense without delving into myths that are connected to the deity or creature, then" +
                    " those details shall be omitted or will have a note saying that further explanation will be" +
                    " found in the myths."
        }
    }

}